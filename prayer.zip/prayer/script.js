
"use strict";

/* ==========================================
   LANGUAGE
========================================== */

let language = "en";
let currentMode = "prayer";
let currentPrayer = "fajr";
let currentStep = 0;

const translations = {
    en: {
        appName: "Prayer Guide",
        title: "Muslim Prayer Guide",
        subtitle: "Learn how to pray, step by step.",
        choosePrayer: "Choose a Prayer",
        fajr: "Fajr",
        dhuhr: "Dhuhr",
        asr: "Asr",
        maghrib: "Maghrib",
        isha: "Isha",
        wudu: "Wudu",
        ablution: "Ablution",
        back: "← Back",
        previous: "← Previous",
        next: "Next →",
        finish: "✓ Finish",
        listen: "🔊 Listen",
        stop: "■ Stop audio",
        step: "Step",
        of: "of",
        disclaimer: "Learning guide. Prayer details can differ between schools of Islamic law.",
        wuduTitle: "Wudu",
        wuduInfo: "Ablution",
        audioUnsupported: "Speech is not supported by this browser.",
        audioUnavailable: "No Arabic speech voice is available. Check your device's speech settings.",
        audioPlaying: "Playing Arabic speech…",
        audioReady: "Press Listen to hear the Arabic text.",
        audioEmpty: "There is no Arabic text for this step.",
        prayerInfo: "Obligatory prayer",
        intention: "Make the intention",
        intentionDesc: "Make the intention in your heart to perform this prayer for Allah. You do not need to pronounce the intention aloud.",
        takbir: "Opening Takbir",
        takbirDesc: "Stand facing the Qiblah and begin the prayer by saying Allahu Akbar.",
        fatiha: "Recite Al-Fatihah",
        fatihaDesc: "While standing, recite Surah Al-Fatihah. In the first two rak'ahs, recite another portion of the Qur'an afterward.",
        ruku: "Ruku' (bowing)",
        rukuDesc: "Bow with your hands on your knees and your back comfortably straight. Say the glorification shown below.",
        rise: "Rise from Ruku'",
        riseDesc: "Return to a standing position. The words and actions of this stage are shown below.",
        sujood: "First Sujood",
        sujoodDesc: "Prostrate with the required body parts on the ground, then glorify Allah.",
        sitting: "Sit between Sujoods",
        sittingDesc: "Rise from the first prostration and sit briefly before the second prostration.",
        secondSujood: "Second Sujood",
        secondSujoodDesc: "Perform the second prostration of this rak'ah.",
        nextRakah: "Continue to the next Rak'ah",
        nextRakahDesc: "Stand and perform the next rak'ah. Recite Al-Fatihah; the additional recitation and other details depend on which rak'ah you are performing.",
        middleSitting: "Middle Tashahhud",
        middleSittingDesc: "For a prayer with three or four rak'ahs, sit for the first Tashahhud after the second rak'ah, then stand to continue. This is not the final sitting.",
        finalSitting: "Final Tashahhud",
        finalSittingDesc: "After the final rak'ah, sit and recite the Tashahhud and blessings upon the Prophet ﷺ.",
        salam: "Finish with Salam",
        salamDesc: "Turn to the right and then the left, saying the Salam to conclude the prayer.",
        wuduIntention: "Intention",
        wuduIntentionDesc: "Intend in your heart to perform Wudu for purification.",
        hands: "Wash both hands",
        handsDesc: "Wash both hands thoroughly, including between the fingers.",
        mouth: "Rinse the mouth",
        mouthDesc: "Take water into your mouth, rinse it, and spit it out.",
        nose: "Clean the nose",
        noseDesc: "Gently draw water into the nose and expel it. Do not harm yourself.",
        face: "Wash the face",
        faceDesc: "Wash the whole face, from the usual hairline to the chin and from ear to ear.",
        arms: "Wash the arms",
        armsDesc: "Wash the right arm including the elbow, then the left arm including the elbow.",
        head: "Wipe the head",
        headDesc: "Wipe the head with wet hands according to your school's method.",
        ears: "Wipe the ears",
        earsDesc: "Wipe the ears with wet fingers according to the method you follow.",
        feet: "Wash the feet",
        feetDesc: "Wash the right foot including the ankle, then the left foot. Make sure water reaches between the toes.",
        wuduComplete: "Wudu complete",
        wuduCompleteDesc: "Your Wudu steps are complete. You can prepare for prayer. Learn the supplication after Wudu from a verified source."
    },

    badini: {
        appName: "ڕێبەرێ نوێژێ",
        title: "ڕێبەرێ نوێژێ",
        subtitle: "فێربە چەوا نوێژێ بکەی، هەنگاو بە هەنگاو.",
        choosePrayer: "نوێژەکێ هەلبژێرە",
        fajr: "بەیانی",
        dhuhr: "نیڤڕۆ",
        asr: "ئەسر",
        maghrib: "مەغریب",
        isha: "عیشا",
        wudu: "دەستنوێژ",
        ablution: "دەستنوێژ",
        back: "← ڤەگەڕە",
        previous: "← پێشوو",
        next: "دویی →",
        finish: "✓ تەمام",
        listen: "🔊 گوهداری بکە",
        stop: "■ دەنگێ بوەستە",
        step: "هەنگاو",
        of: "ژ",
        disclaimer: "ڕێبەرەکا فێرکارییە. هەندەک وردەکاریێن نوێژێ د ناڤ مەزهەبان دا جودان.",
        wuduTitle: "دەستنوێژ",
        wuduInfo: "دەستنوێژ",
        audioUnsupported: "ڤی براوزەری پشتیوانیا دەنگێ گوتاری نینە.",
        audioUnavailable: "دەنگێ عەرەبی نینە. ڕێکخستنێن دەنگێ ئامێرێ خۆ بپشکنە.",
        audioPlaying: "دەنگێ عەرەبی دهێتە پەخشکرن…",
        audioReady: "بۆ گوهداریکرنێ ل سەر گوهداری بکە کلیک بکە.",
        audioEmpty: "د ڤی هەنگاڤی دا دەقێ عەرەبی نینە.",
        prayerInfo: "نوێژا فەرز",
        intention: "نیەت بکە",
        intentionDesc: "د دڵێ خۆدا نیەت بکە کو ڤی نوێژێ بۆ خودێ بکەی. پێدڤی ناکەت نیەتێ ب دەنگێ بلند بێژی.",
        takbir: "تەکبیرا دەستپێکێ",
        takbirDesc: "بەرەڤ قیبلەیێ ڕاوەستە و ب گوتنا الله أكبر نوێژێ دەست پێ بکە.",
        fatiha: "سورەتا فاتحە بخوینە",
        fatihaDesc: "د ڕاوەستانێ دا سورەتا فاتحە بخوینە. د دوو ڕەکعەتێن ئێکێ دا، پشتی فاتحەیێ پارچەیەک ژ قورئانێ بخوینە.",
        ruku: "ڕکووع",
        rukuDesc: "ڕکووع بکە و دەستان ل سەر ئەژنۆیان دابنێ و پشتا خۆ ڕاست راگرە. تەسبیحا نیشاندایی ٣ جاران بخوینە.",
        rise: "ڕابوون ژ ڕکووعێ",
        riseDesc: "ڤەگەڕە ب ڕاوەستانێ. گوتن و کردارێن ڤی هەنگاڤی ل خوارێ نیشان ددەن.",
        sujood: "سجودا ئێکێ",
        sujoodDesc: "سجود بکە و ئەندامێن پێدڤی ل سەر ئەردی دابنێ، پاشی  ٣ جاران تسبیح بکە.",
        sitting: "دانیشتن د ناڤبەرا دوو سجودان دا",
        sittingDesc: "ژ سجودا ئێکێ رابە و کورتەکێ دانیشە پێش سجودا دووێ.",
        secondSujood: "سجودا دووێ",
        secondSujoodDesc: "سجودا دووێ یا ڤێ ڕەکعەتێ بکە.",
        nextRakah: "بەردەوام بە بۆ ڕەکعەتا پشتی",
        nextRakahDesc: "ڕابە و ڕەکعەتا پشتی بکە. فاتحە بخوینە؛ خواندنا زیادە و هەندەک وردەکاری ب ڕەکعەتێ ڤە گرێدایە.",
        middleSitting: "تەشەهھودا ناڤەڕاست",
        middleSittingDesc: "د نوێژا سێ یان چار ڕەکعەتان دا، پشتی ڕەکعەتا دووێ بۆ تەشەهھودێ دانیشە، پاشی ڕابە و بەردەوام بە. ئەڤە دانیشتنا دووماهی نینە.",
        finalSitting: "تەشەهھودا دووماهی",
        finalSittingDesc: "پشتی ڕەکعەتا دووماهی، دانیشە و تەشەهھود و سەلاواتێ ل سەر پێغەمبەر ﷺ بخوینە.",
        salam: "ب سەلامێ تەواو بکە",
        salamDesc: "سەرێ خۆ بەرەڤ ڕاستێ و پاشی بەرەڤ چەپێ بگەڕینە و سەلامێ بدە.",
        wuduIntention: "نیەت",
        wuduIntentionDesc: "د دڵێ خۆدا نیەت بکە بۆ پاکبوونێ دەستنوێژێ بکەی.",
        hands: "هەردوو دەستان بشۆ",
        handsDesc: "هەردوو دەستێن خۆ باش بشۆ، ناڤبەرا پەنجان ژی بشۆ.",
        mouth: "دەڤێ خۆ بشۆ",
        mouthDesc: "ئاڤێ د دەڤێ خۆدا بگەڕینە و دەرێخە.",
        nose: "پزێ خۆ پاک بکە",
        noseDesc: "ب نەرمی ئاڤێ ب پزێ خۆ بکە و دەرێخە. خۆ نەئێشینە.",
        face: "ڕوویێ خۆ بشۆ",
        faceDesc: "هەمی ڕوویێ خۆ بشۆ، ژ شوێنێ ئاساییێ موویێ سەرێ تا چەناگە و ژ گوەکێ تا گوەکێ.",
        arms: "بازووان بشۆ",
        armsDesc: "بازوویێ ڕاست تا ئەژنۆ بشۆ، پاشی بازوویێ چەپ تا ئەژنۆ بشۆ.",
        head: "سەرێ خۆ مەسح بکە",
        headDesc: "ب دەستێن تەڕ سەرێ خۆ مەسح بکە ب شێوازێ مەزهەبا خۆ.",
        ears: "گوهان مەسح بکە",
        earsDesc: "ب پەنجێن تەڕ گوهان مەسح بکە ب شێوازێ مەزهەبا خۆ.",
        feet: "پێیێن خۆ بشۆ",
        feetDesc: "پێیێ ڕاست تا قوزکێ بشۆ، پاشی پێیێ چەپ. ئاڤ بگەهێتە ناڤبەرا پەنجێن پێ.",
        wuduComplete: "دەستنوێژ تەواو بوو",
        wuduCompleteDesc: "هەنگاوێن دەستنوێژێ تەواو بوون. نوکە دکاریت بۆ نوێژێ ئامادە ببیت. دوعایێ پشتی دەستنوێژێ ژ سەرچاوەیەکا پشتڕاست بخوینە."
    }
};


/* ==========================================
   PRAYER CONTENT
========================================== */

function makeStep(title, description, arabic = "", translation = "") {
    return {
        title,
        description,
        arabic,
        translation
    };
}

const text = (en, badini) => ({ en, badini });

const prayerNames = {
    fajr: text("Fajr", "بەیانی"),
    dhuhr: text("Dhuhr", "نیڤڕۆ"),
    asr: text("Asr", "ئەسر"),
    maghrib: text("Maghrib", "مەغریب"),
    isha: text("Isha", "عیشا")
};

function buildPrayerSteps(numberOfRakahs) {
    const steps = [];
    const T = key => text(translations.en[key], translations.badini[key]);

    steps.push(makeStep(
        T("intention"),
        T("intentionDesc")
    ));

    steps.push(makeStep(
        T("takbir"),
        T("takbirDesc"),
        "اللَّهُ أَكْبَرُ",
        text("Allah is the Greatest.", "خودێ مەزنترە.")
    ));

    for (let r = 1; r <= numberOfRakahs; r++) {
        steps.push(makeStep(
            text(`Rak'ah ${r}: Recitation`, `ڕەکعەتا ${r}: خواندن`),
            text(
                r <= 2
                    ? "While standing, recite Al-Fatihah and another portion of the Qur'an."
                    : "While standing, recite Al-Fatihah. Details of additional recitation depend on the school you follow.",
                r <= 2
                    ? "د ڕاوەستانێ دا فاتحە و پارچەیەک ژ قورئانێ بخوینە."
                    : "د ڕاوەستانێ دا فاتحە بخوینە. وردەکاریێن خواندنا زیادە ب مەزهەبا تە ڤە گرێدایە."
            ),
            "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ",
            text(
                "All praise belongs to Allah, Lord of the worlds.",
                "هەمی حەمد بۆ خودێیە، خودانێ جیهانان."
            )
        ));

        steps.push(makeStep(
            T("ruku"),
            T("rukuDesc"),
            "سُبْحَانَ رَبِّيَ الْعَظِيمِ",
            text(
                "Glory be to my Lord, the Most Great.",
                "پاک و بێخەلەلە خودانێ منێ مەزن."
            )
        ));

        steps.push(makeStep(
            T("rise"),
            T("riseDesc"),
            "  سَمِعَ اللَّهُ لِمَنْ حَمِدَهُ ،رَبَّنَا وَلَكَ الْحَمْدُ",
            text(
                "Allah hears the one who praises Him.",
                "خودێ گوهداری کەسێ دکەت کو حەمدێ دکەت."
            )
        ));

        steps.push(makeStep(
            T("sujood"),
            T("sujoodDesc"),
            "سُبْحَانَ رَبِّيَ الْأَعْلَى",
            text(
                "Glory be to my Lord, the Most High.",
                "پاک و بێخەلەلە خودانێ منێ بەرز."
            )
        ));

        steps.push(makeStep(
            T("sitting"),
            T("sittingDesc"),
            "رَبِّ اغْفِرْ لِي",
            text(
                "My Lord, forgive me.",
                "ئەی خودانێ من، من ببورە."
            )
        ));

        steps.push(makeStep(
            T("secondSujood"),
            T("secondSujoodDesc"),
            "سُبْحَانَ رَبِّيَ الْأَعْلَى",
            text(
                "Glory be to my Lord, the Most High.",
                "پاک و بێخەلەلە خودانێ منێ بەرز."
            )
        ));

        if (r === 2 && numberOfRakahs > 2) {
            steps.push(makeStep(
                T("middleSitting"),
                T("middleSittingDesc"),
                "التَّحِيَّاتُ لِلَّهِ",
                text(
                    "The opening words of the Tashahhud.",
                    "دەستپێکا تەشەهھودێ."
                )
            ));
        }

        if (r < numberOfRakahs) {
            steps.push(makeStep(
                T("nextRakah"),
                T("nextRakahDesc")
            ));
        }
    }

    steps.push(makeStep(
        T("finalSitting"),
        T("finalSittingDesc"),
        "التَّحِيَّاتُ لِلَّهِ وَالصَّلَوَاتُ وَالطَّيِّبَاتُ",
        text(
            "All greetings, prayers and good things belong to Allah.",
            "هەمی سلاڤ و نوێژ و پاکی بۆ خودێنە."
        )
    ));

    steps.push(makeStep(
        T("finalSitting"),
        text(
            "Recite the blessings upon the Prophet ﷺ as taught in your prayer tradition.",
            "سەلاواتێ ل سەر پێغەمبەر ﷺ بخوینە ب شێوازێ فێربووی."
        ),
        "اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ",
        text(
            "O Allah, send blessings upon Muhammad.",
            "ئەی خودێ، سەلاواتێ ل سەر محەممەد بنێرە."
        )
    ));

    steps.push(makeStep(
        T("salam"),
        T("salamDesc"),
        "السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ",
        text(
            "Peace and mercy of Allah be upon you.",
            "سلاڤ و ڕەحمەتا خودێ ل سەر هەوە بیت."
        )
    ));

    return steps;
}

const prayers = {
    fajr: {
        icon: "🌅",
        rakahs: "2 Rak'ahs",
        steps: buildPrayerSteps(2)
    },
    dhuhr: {
        icon: "☀️",
        rakahs: "4 Rak'ahs",
        steps: buildPrayerSteps(4)
    },
    asr: {
        icon: "🌤️",
        rakahs: "4 Rak'ahs",
        steps: buildPrayerSteps(4)
    },
    maghrib: {
        icon: "🌇",
        rakahs: "3 Rak'ahs",
        steps: buildPrayerSteps(3)
    },
    isha: {
        icon: "🌙",
        rakahs: "4 Rak'ahs",
        steps: buildPrayerSteps(4)
    }
};


/* ==========================================
   WUDU CONTENT
========================================== */

const wuduSteps = [
    {
        key: "wuduIntention",
        arabic: "",
        translation: ""
    },
    {
        key: "hands",
        arabic: "",
        translation: ""
    },
    {
        key: "mouth",
        arabic: "",
        translation: ""
    },
    {
        key: "nose",
        arabic: "",
        translation: ""
    },
    {
        key: "face",
        arabic: "",
        translation: ""
    },
    {
        key: "arms",
        arabic: "",
        translation: ""
    },
    {
        key: "head",
        arabic: "",
        translation: ""
    },
    {
        key: "ears",
        arabic: "",
        translation: ""
    },
    {
        key: "feet",
        arabic: "",
        translation: ""
    },
    {
        key: "wuduComplete",
        arabic: "",
        translation: ""
    }
];


/* ==========================================
   LANGUAGE SWITCHER
========================================== */

function changeLanguage() {
    language = language === "en" ? "badini" : "en";
    applyLanguage();
}

function applyLanguage() {
    const t = translations[language];

    document.querySelectorAll("[data-i18n]").forEach(element => {
        const key = element.getAttribute("data-i18n");
        if (t[key]) {
            element.textContent = t[key];
        }
    });

    document.getElementById("languageBtn").textContent =
        language === "en" ? "کوردی" : "English";

    document.body.classList.toggle("rtl", language === "badini");
    document.documentElement.lang = language === "en" ? "en" : "ku";

    if (!document.getElementById("guide").classList.contains("hidden")) {
        showStep();
    }
}


/* ==========================================
   OPEN GUIDES
========================================== */

function openPrayer(name) {
    stopArabic();

    currentMode = "prayer";
    currentPrayer = name;
    currentStep = 0;

    document.getElementById("home").classList.add("hidden");
    document.getElementById("guide").classList.remove("hidden");

    showStep();
}

function openWudu() {
    stopArabic();

    currentMode = "wudu";
    currentStep = 0;

    document.getElementById("home").classList.add("hidden");
    document.getElementById("guide").classList.remove("hidden");

    showStep();
}


/* ==========================================
   GET CURRENT STEPS
========================================== */

function getCurrentSteps() {
    if (currentMode === "wudu") {
        return wuduSteps;
    }

    return prayers[currentPrayer].steps;
}


/* ==========================================
   SHOW STEP
========================================== */

function showStep() {
    const t = translations[language];
    const steps = getCurrentSteps();
    const step = steps[currentStep];

    if (!step) return;

    let title;
    let icon;
    let info;
    let heading;
    let description;
    let arabic;
    let translation;

    if (currentMode === "wudu") {
        title = t.wuduTitle;
        icon = "💧";
        info = t.wuduInfo;
        heading = t[step.key];
        description = t[step.key + "Desc"];
        arabic = step.arabic;
        translation = step.translation;
    } else {
        const prayer = prayers[currentPrayer];
        const original = prayer.steps[currentStep];

        title = prayerNames[currentPrayer][language];
        icon = prayer.icon;
        info = language === "en" ? prayer.rakahs : t.prayerInfo;
        heading = original.title[language];
        description = original.description[language];
        arabic = original.arabic;
        translation = original.translation
            ? original.translation[language]
            : "";
    }

    document.getElementById("guideIcon").textContent = icon;
    document.getElementById("guideTitle").textContent = title;
    document.getElementById("guideInfo").textContent = info;
    document.getElementById("stepNumber").textContent = currentStep + 1;
    document.getElementById("stepCount").textContent =
        `${t.step} ${currentStep + 1} ${t.of} ${steps.length}`;

    document.getElementById("stepTitle").textContent = heading || "";
    document.getElementById("stepDescription").textContent = description || "";
    document.getElementById("arabicText").textContent = arabic || "";
    document.getElementById("translationText").textContent = translation || "";

    document.getElementById("progressBar").style.width =
        ((currentStep + 1) / steps.length * 100) + "%";

    document.getElementById("previousBtn").disabled = currentStep === 0;
    document.getElementById("previousBtn").textContent = t.previous;
    document.getElementById("nextBtn").textContent =
        currentStep === steps.length - 1 ? t.finish : t.next;

    document.getElementById("audioButton").textContent = t.listen;
    document.getElementById("audioButton").style.display =
        arabic && arabic.trim() ? "inline-block" : "none";

    document.getElementById("audioStatus").textContent = "";
}


/* ==========================================
   NAVIGATION
========================================== */

function nextStep() {
    const steps = getCurrentSteps();

    if (currentStep < steps.length - 1) {
        currentStep++;
        stopArabic();
        showStep();
    } else {
        goHome();
    }
}

function previousStep() {
    if (currentStep > 0) {
        currentStep--;
        stopArabic();
        showStep();
    }
}

function goHome() {
    stopArabic();

    document.getElementById("guide").classList.add("hidden");
    document.getElementById("home").classList.remove("hidden");

    currentStep = 0;
}


/* ==========================================
   ARABIC SPEECH
========================================== */

function playArabic() {
    const arabic = document.getElementById("arabicText").textContent.trim();
    const status = document.getElementById("audioStatus");

    if (!arabic) {
        status.textContent = translations[language].audioEmpty;
        return;
    }

    if (!("speechSynthesis" in window)) {
        status.textContent = translations[language].audioUnsupported;
        return;
    }

    window.speechSynthesis.cancel();

    const voices = window.speechSynthesis.getVoices();
    const arabicVoice = voices.find(voice =>
        voice.lang.toLowerCase().startsWith("ar")
    );

    if (voices.length > 0 && !arabicVoice) {
        status.textContent = translations[language].audioUnavailable;
        return;
    }

    const utterance = new SpeechSynthesisUtterance(arabic);
    utterance.lang = arabicVoice ? arabicVoice.lang : "ar-SA";
    utterance.rate = 0.75;
    utterance.pitch = 1;

    if (arabicVoice) {
        utterance.voice = arabicVoice;
    }

    utterance.onstart = () => {
        status.textContent = translations[language].audioPlaying;
    };

    utterance.onend = () => {
        status.textContent = "";
    };

    utterance.onerror = () => {
        status.textContent = translations[language].audioUnavailable;
    };

    window.speechSynthesis.speak(utterance);
}

function stopArabic() {
    if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
    }

    const status = document.getElementById("audioStatus");
    if (status) status.textContent = "";
}


/* ==========================================
   INITIALIZE
========================================== */

document.addEventListener("DOMContentLoaded", () => {
    applyLanguage();
});